#ifndef RS_mBotLib_
#define RS_mBotLib_

/*
#include <MeMCore.h>
#include <Arduino.h>
#include <Wire.h>
#include <SoftwareSerial.h>
*/
/*MeLEDMatrix ledMx(PORT_4);
unsigned char MatrixArray[16];
unsigned char *arrow_direction;
*/
void MatrixGoForward();
void MatrixTurnRight();
void MatrixTurnLeft();
void MatrixGoBack();
void MatrixStop();


#endif
