#include "RSmBotLib.h"

#include <MeMCore.h>
#include <Arduino.h>
#include <Wire.h>
#include <SoftwareSerial.h>

MeLEDMatrix ledMx(PORT_4);
unsigned char MatrixArray[16];
unsigned char *arrow_direction;

void MatrixGoForward(){
  arrow_direction = new unsigned char[sizeof(MatrixArray)]{0,0,0,0,8,24,56,127,255,127,56,24,8,0,0,0};  //up
  memcpy(MatrixArray, arrow_direction, sizeof(MatrixArray));
  ledMx.drawBitmap(0, 0, sizeof(MatrixArray), MatrixArray);
}

void MatrixTurnRight(){
  arrow_direction = new unsigned char[sizeof(MatrixArray)]{0,0,24,24,24,24,24,24,24,255,255,126,60,24,0,0};  //right
  memcpy(MatrixArray, arrow_direction, sizeof(MatrixArray));
  ledMx.drawBitmap(0, 0, sizeof(MatrixArray), MatrixArray);
}
  
void MatrixTurnLeft(){
  arrow_direction = new unsigned char[sizeof(MatrixArray)]{0,0,24,60,126,255,255,24,24,24,24,24,24,24,0,0};  //left
  memcpy(MatrixArray, arrow_direction, sizeof(MatrixArray));
  ledMx.drawBitmap(0, 0, sizeof(MatrixArray), MatrixArray);
}

void MatrixGoBack(){
  arrow_direction = new unsigned char[sizeof(MatrixArray)]{0,0,0,0,16,24,28,254,255,254,28,24,16,0,0,0};  //down
  memcpy(MatrixArray, arrow_direction, sizeof(MatrixArray));
  ledMx.drawBitmap(0, 0, sizeof(MatrixArray), MatrixArray);
}

void MatrixStop(){
  arrow_direction = new unsigned char[sizeof(MatrixArray)]{116,84,92,0,64,124,64,0,56,68,68,56,0,124,80,112};  //stop
  memcpy(MatrixArray, arrow_direction, sizeof(MatrixArray));
  ledMx.drawBitmap(0, 0, sizeof(MatrixArray), MatrixArray);
  }
